

<img src="<?php echo e(asset('images/logo.png')); ?>" style="background:#0a0f1bd2; border-radius:100%; padding:10px; width:70px;"><?php /**PATH C:\xampp\htdocs\vmail_laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>